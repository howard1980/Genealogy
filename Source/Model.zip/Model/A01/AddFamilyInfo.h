﻿//
//  AddFamilyInfo.h
//  Genealogy
//
//  Created by xiao huama on 15/09/07.
//  Xiao Hua Ma personal studio 2015.
//
#import "ServiceBaseModel.h"
#import "UserInfoDTO.h"

@interface AddFamilyInfo : ServiceBaseModel


- (void)postData:(NSMutableString *)userID familyID:(NSMutableString *)familyID userInfo:(UserInfoDTO *)userInfo;

@end
