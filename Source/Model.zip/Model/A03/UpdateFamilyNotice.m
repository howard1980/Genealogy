﻿//
//  UpdateFamilyNotice.m
//  Genealogy
//
//  Created by xiao huama on 15/09/07.
//  Xiao Hua Ma personal studio 2015.
//

#import "UpdateFamilyNotice.h"

@interface UpdateFamilyNotice()
@property(nonatomic,strong)NSMutableString *userID; /**< 用户ID*/
@property(nonatomic,strong)NSMutableString *noticeID; /**< 通告ID*/
@property(nonatomic,strong)NSMutableString *content; /**< 通告内容*/
@property(nonatomic,strong)NSMutableString *date; /**< 日期*/
@property(nonatomic,strong)NSMutableString *time; /**< 时间*/
@property(nonatomic,strong)AddressInfoDTO *address; /**< 地点*/
@property(nonatomic,strong)NSMutableArray *clansmanID; /**< 人员ID列表*/
@end
@implementation UpdateFamilyNotice

- (instancetype)init
{
    self = [super init];
    if (self) {
        serviceMethod = @"FsUpdateFamilyNotice";
        self.className = @"UpdateFamilyNotice";
    }
    return self;
}

- (void)postData:(NSMutableString *)userID noticeID:(NSMutableString *)noticeID content:(NSMutableString *)content date:(NSMutableString *)date time:(NSMutableString *)time address:(AddressInfoDTO *)address clansmanID:(NSMutableArray *)clansmanID{
    self.userID = userID;
    self.noticeID = noticeID;
    self.content = content;
    self.date = date;
    self.time = time;
    self.address = address;
    self.clansmanID = clansmanID;
    [self requestWebService:^{
        if (delegate) {
            [delegate successMethd:self];
        }
    } faild:^{
        if (delegate) {
            [delegate errorMethd];
        }
    }];
}

-(NSMutableDictionary *)buildRequestData
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    if (self.userID) {
        dic[@"userID"] = self.userID;
    }
    if (self.noticeID) {
        dic[@"noticeID"] = self.noticeID;
    }
    if (self.content) {
        dic[@"content"] = self.content;
    }
    if (self.date) {
        dic[@"date"] = self.date;
    }
    if (self.time) {
        dic[@"time"] = self.time;
    }
    if (self.clansmanID.count>0) {
        dic[@"clansmanID"] = self.clansmanID;
    }
    NSDictionary *addressDic = [self.address buildRequestData];
    if (addressDic) {
        dic[@"address"] = addressDic;
    }
    return dic;
}

- (void)loadDataWithJsonData:(id)jsonData
{
    if (![jsonData isKindOfClass:[NSDictionary class]]) {
        return;
    }
    if (!jsonData) {
        return;
    }
}

-(BOOL)checkRequired
{
    NSMutableArray *muArray = [[NSMutableArray alloc] init];
    BOOL rest = YES;
    if (self.userID.length<1) {
        [muArray addObject:@"用户ID不能为空!"];
        rest = NO;
    }
    if (self.noticeID.length<1) {
        [muArray addObject:@"通告ID不能为空!"];
        rest = NO;
    }
    
    if (!rest){
        self.exceptions = muArray;
    }
    return rest;
}

@end
