﻿//
//  Login.h
//  Genealogy
//
//  Created by xiao huama on 15/09/07.
//  Xiao Hua Ma personal studio 2015.
//
#import "ServiceBaseModel.h"
#import "UserInfoDTO.h"
#import "FamilyInfoDTO.h"

@interface Login : ServiceBaseModel

@property(nonatomic,strong)UserInfoDTO *userInfo; /**< 用户信息*/
@property(nonatomic,strong)NSMutableArray *familyInfoArray; /**< 家族信息*/

- (void)postData:(NSMutableString *)mobile validCode:(NSMutableString *)validCode familyCode:(NSMutableString *)familyCode imsi:(NSNumber *)imsi regisitrationID:(NSMutableString *)regisitrationID longitude:(NSNumber *)longitude latitude:(NSNumber *)latitude cityCode:(NSMutableString *)cityCode;

@end
