﻿//
//  UpdateAction.h
//  Genealogy
//
//  Created by xiao huama on 15/09/07.
//  Xiao Hua Ma personal studio 2015.
//
#import "ServiceBaseModel.h"
#import "ActionDTO.h"

@interface UpdateAction : ServiceBaseModel


- (void)postData:(NSMutableString *)userID action:(ActionDTO *)action;

@end
