﻿//
//  UpdateQuestion.h
//  Genealogy
//
//  Created by xiao huama on 15/09/07.
//  Xiao Hua Ma personal studio 2015.
//
#import "ServiceBaseModel.h"

@interface UpdateQuestion : ServiceBaseModel


- (void)postData:(NSMutableString *)userID question:(NSMutableString *)question;

@end
