﻿//
//  UpdatePhone.h
//  Genealogy
//
//  Created by xiao huama on 15/09/07.
//  Xiao Hua Ma personal studio 2015.
//
#import "ServiceBaseModel.h"

@interface UpdatePhone : ServiceBaseModel


- (void)postData:(NSMutableString *)userID mobile:(NSMutableString *)mobile validCode:(NSMutableString *)validCode;

@end
