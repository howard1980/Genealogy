﻿//
//  RemovPeople.h
//  Genealogy
//
//  Created by xiao huama on 15/09/07.
//  Xiao Hua Ma personal studio 2015.
//
#import "ServiceBaseModel.h"

@interface RemovPeople : ServiceBaseModel


- (void)postData:(NSMutableString *)userID familyID:(NSNumber *)familyID;

@end
