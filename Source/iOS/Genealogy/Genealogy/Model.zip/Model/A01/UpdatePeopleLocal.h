﻿//
//  UpdatePeopleLocal.h
//  Genealogy
//
//  Created by xiao huama on 15/09/07.
//  Xiao Hua Ma personal studio 2015.
//
#import "ServiceBaseModel.h"

@interface UpdatePeopleLocal : ServiceBaseModel


- (void)postData:(NSMutableString *)userID longitude:(NSNumber *)longitude latitude:(NSNumber *)latitude title:(NSMutableString *)title;

@end
