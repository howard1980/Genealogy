﻿//
//  AddFamilyNotice.h
//  Genealogy
//
//  Created by xiao huama on 15/09/07.
//  Xiao Hua Ma personal studio 2015.
//
#import "ServiceBaseModel.h"
#import "AddressInfoDTO.h"

@interface AddFamilyNotice : ServiceBaseModel


- (void)postData:(NSMutableString *)userID content:(NSMutableString *)content date:(NSMutableString *)date time:(NSMutableString *)time address:(AddressInfoDTO *)address clansmanID:(NSMutableArray *)clansmanID;

@end
