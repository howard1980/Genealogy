﻿//
//  UploadComment.h
//  Genealogy
//
//  Created by xiao huama on 15/09/07.
//  Xiao Hua Ma personal studio 2015.
//
#import "ServiceBaseModel.h"

@interface UploadComment : ServiceBaseModel


- (void)postData:(NSMutableString *)userID actionID:(NSMutableString *)actionID comment:(NSMutableString *)comment;

@end
