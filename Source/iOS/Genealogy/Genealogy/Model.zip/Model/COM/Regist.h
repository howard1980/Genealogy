﻿//
//  Regist.h
//  Genealogy
//
//  Created by xiao huama on 15/09/07.
//  Xiao Hua Ma personal studio 2015.
//
#import "ServiceBaseModel.h"

@interface Regist : ServiceBaseModel

@property(nonatomic,strong)NSMutableString *userID; /**< 用户ID*/

- (void)postData:(NSMutableString *)mobile validCode:(NSMutableString *)validCode imsi:(NSNumber *)imsi regisitrationID:(NSMutableString *)regisitrationID longitude:(NSNumber *)longitude latitude:(NSNumber *)latitude cityCode:(NSMutableString *)cityCode;

@end
